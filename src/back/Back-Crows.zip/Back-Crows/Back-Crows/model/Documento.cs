﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Back_Crows.model
{
    [Table("Documentos")]
    public class Documento
    {
        [Key]
        [Display(Name = "Id")]
        public int Id { get; set; }

        [Display(Name = "Tipo")]
        [Required(ErrorMessage = "O campo tipo é obrigatório.")]
        public string Tipo { get; set; }

        [Display(Name = "Dados")]
        [Required(ErrorMessage = "O campo Dados é obrigatório.")]
        public string Dados { get; set; }

        [Display(Name = "Data de Envio")]
        [Required(ErrorMessage = "O campo Data de Envio é obrigatório.")]
        public DateTime DataEnvio { get; set; }

        [Display(Name = "Indexado para IA")]
        public bool IndexadoParaIa { get; set; }

        [Display(Name = "Usuário")]
        [ForeignKey("Usuario")]
        public int UsuarioId { get; set; }
        public Usuario Usuario { get; set; }

        [Display(Name = "Organização")]
        [ForeignKey("Organizacao")]
        public int OrganizacaoId { get; set; }
        public Organizacao Organizacao { get; set; }
    }
}
