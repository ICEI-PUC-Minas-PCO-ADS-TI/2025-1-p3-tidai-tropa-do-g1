﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Back_Crows.model
{
    [Table("Organizacoes")]
    public class Organizacao
    {
        [Key]
        [Display(Name = "Id")]
        public int Id { get; set; }

        [Display(Name = "Nome")]
        [Required(ErrorMessage = "O campo nome é obrigatório.")]
        public string Nome { get; set; }

        [Display(Name = "CNPJ")]
        [Required(ErrorMessage = "O campo CNPJ é obrigatório.")]
        public string Cnpj { get; set; }

        [Display(Name = "Data de Criação")]
        [Required(ErrorMessage = "O campo Data de Criação é obrigatório.")]
        public DateTime DataCriacao { get; set; }

        [Display(Name = "Ramo")]
        [Required(ErrorMessage = "O campo Ramo é obrigatório.")]
        public string Ramo { get; set; }

        [Display(Name = "Telefone")]
        [Required(ErrorMessage = "O campo Telefone é obrigatório.")]
        public string Telefone { get; set; }

        [Display(Name = "CEP")]
        [Required(ErrorMessage = "O campo CEP é obrigatório.")]
        public string Cep { get; set; }

        [Display(Name = "E-mail")]
        [Required(ErrorMessage = "O campo e-mail é obrigatório.")]
        [EmailAddress(ErrorMessage = "E-mail invalido!")]
        public string Email { get; set; }

        [Display(Name = "Senha")]
        [Required(ErrorMessage = "O campo senha é obrigatório.")]
        [DataType(DataType.Password)]
        public string Senha { get; set; }

        [Display(Name = "Imagem do Perfil")]
        public string? ImagemPerfil { get; set; }


        // Relacionamentos:

        public ICollection<Usuario> Usuarios { get; set; } = new List<Usuario>();

        public ICollection<Grupo> Grupos { get; set; } = new List<Grupo>();

        public ICollection<Documento> Documentos { get; set; } = new List<Documento>();
    }
}
