﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Back_Crows.model
{
    [Table("Usuarios")]
    public class Usuario
    {
        [Key]
        [Display(Name = "Id")]
        public int Id { get; set; }

        [Display(Name = "Nome")]
        [Required(ErrorMessage = "O campo nome é obrigatório.")]
        public string Nome { get; set; }

        [Display(Name = "Documento")]
        [Required(ErrorMessage = "O campo documento é obrigatório.")]
        public string Documento { get; set; }

        [Display(Name = "Tipo do Documento")]
        [Required(ErrorMessage = "O campo Tipo do Documento é obrigatório.")]
        public string TipoDocumento { get; set; }

        [Display(Name = "Data de Nascimento")]
        [Required(ErrorMessage = "O campo Data de Nascimento é obrigatório.")]
        public DateTime DataNascimento { get; set; }

        [Display(Name = "E-mail")]
        [Required(ErrorMessage = "O campo e-mail é obrigatório.")]
        [EmailAddress(ErrorMessage = "E-mail inválido!")]
        public string Email { get; set; }

        [Display(Name = "Senha")]
        [Required(ErrorMessage = "O campo senha é obrigatório.")]
        [DataType(DataType.Password)]
        public string Senha { get; set; }

        [Display(Name = "Tipo do Usuário")]
        [Required(ErrorMessage = "O campo Tipo do Usuário é obrigatório.")]
        public string TipoUsuario { get; set; }

        [Display(Name = "Ativo")]
        public bool? Ativo { get; set; }

        // chave estrangeira
        [Display(Name = "Organização")]
        
        public int OrganizacaoId { get; set; }

        [ForeignKey("OrganizacaoId")]
        public Organizacao? Organizacao { get; set; }

        // Relacionamentos
        public ICollection<GrupoUsuario> GrupoUsuarios { get; set; } = new List<GrupoUsuario>();
    }
}
