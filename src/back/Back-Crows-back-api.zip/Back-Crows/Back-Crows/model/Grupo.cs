﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Back_Crows.model
{
    [Table("Grupos")]
    public class Grupo
    {
        [Key]
        [Display(Name = "Id")]
        public int Id { get; set; }

        [Display(Name = "Nome")]
        [Required(ErrorMessage = "O campo nome é obrigatório.")]
        public string Nome { get; set; }

        [Display(Name = "Descrição")]
        [Required(ErrorMessage = "O campo descrição é obrigatório.")]
        public string Descricao { get; set; }

        [Display(Name = "Tipo")]
        [Required(ErrorMessage = "O campo tipo é obrigatório.")]
        public string Tipo { get; set; }

        [Display(Name = "Organização")]
        
        public int OrganizacaoId { get; set; }

        [ForeignKey("OrganizacaoId")]
        public Organizacao Organizacao { get; set; }

        public ICollection<GrupoUsuario> GrupoUsuarios { get; set; } = new List<GrupoUsuario>();
    }
}
