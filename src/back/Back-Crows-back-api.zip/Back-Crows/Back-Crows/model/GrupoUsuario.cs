﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Back_Crows.model
{
    // Tabela de associação entre usuários e grupos N:N
    [Table("GrupoUsuarios")]
    public class GrupoUsuario
    {
        public int UsuarioId { get; set; }
        public Usuario Usuario { get; set; }
        
        public int GrupoId { get; set; }
        public Grupo Grupo { get; set; }
    }
}
