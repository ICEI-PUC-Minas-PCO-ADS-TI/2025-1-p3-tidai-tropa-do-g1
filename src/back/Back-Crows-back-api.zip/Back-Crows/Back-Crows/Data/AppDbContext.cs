﻿using Back_Crows.model;
using Microsoft.EntityFrameworkCore;

namespace Back_Crows.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options)
            : base(options)
        {
        }

        // DbSet para cada model
        public DbSet<Usuario> Usuarios { get; set; }
        public DbSet<Grupo> Grupos { get; set; }
        public DbSet<Organizacao> Organizacoes { get; set; }
        public DbSet<Documento> Documentos { get; set; }
        public DbSet<GrupoUsuario> GrupoUsuarios { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Configuração da chave composta e relacionamentos da tabela de associação
            modelBuilder.Entity<GrupoUsuario>()
                .HasKey(x => new { x.UsuarioId, x.GrupoId });

            modelBuilder.Entity<GrupoUsuario>()
                .HasOne(gu => gu.Usuario)
                .WithMany(u => u.GrupoUsuarios)
                .HasForeignKey(gu => gu.UsuarioId);

            modelBuilder.Entity<GrupoUsuario>()
                .HasOne(gu => gu.Grupo)
                .WithMany(g => g.GrupoUsuarios)
                .HasForeignKey(gu => gu.GrupoId);

            base.OnModelCreating(modelBuilder);
        }
    }
}
