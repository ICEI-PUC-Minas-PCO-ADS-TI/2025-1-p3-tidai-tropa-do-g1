﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Back_Crows.Data;
using Back_Crows.model;

namespace Back_Crows.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrganizacoesController : ControllerBase
    {
        private readonly AppDbContext _context;

        public OrganizacoesController(AppDbContext context)
        {
            _context = context;
        }

        // GET: api/Organizacoes
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Organizacao>>> GetOrganizacoes()
        {
            return await _context.Organizacoes.ToListAsync();
        }

        // GET: api/Organizacoes/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Organizacao>> GetOrganizacao(int id)
        {
            var organizacao = await _context.Organizacoes.FindAsync(id);

            if (organizacao == null)
            {
                return NotFound();
            }

            return organizacao;
        }

        // PUT: api/Organizacoes/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutOrganizacao(int id, Organizacao organizacao)
        {
            if (id != organizacao.Id)
            {
                return BadRequest();
            }

            _context.Entry(organizacao).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!OrganizacaoExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Organizacoes
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<Organizacao>> PostOrganizacao(Organizacao organizacao)
        {
            _context.Organizacoes.Add(organizacao);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetOrganizacao", new { id = organizacao.Id }, organizacao);
        }

        // DELETE: api/Organizacoes/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteOrganizacao(int id)
        {
            var organizacao = await _context.Organizacoes.FindAsync(id);
            if (organizacao == null)
            {
                return NotFound();
            }

            _context.Organizacoes.Remove(organizacao);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool OrganizacaoExists(int id)
        {
            return _context.Organizacoes.Any(e => e.Id == id);
        }
    }
}
