﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Back_Crows.Data;
using Back_Crows.model;

namespace Back_Crows.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GrupoUsuariosController : ControllerBase
    {
        private readonly AppDbContext _context;

        public GrupoUsuariosController(AppDbContext context)
        {
            _context = context;
        }

        // GET: api/GrupoUsuarios
        [HttpGet]
        public async Task<ActionResult<IEnumerable<GrupoUsuario>>> GetGrupoUsuarios()
        {
            return await _context.GrupoUsuarios.ToListAsync();
        }

        // GET: api/GrupoUsuarios/5
        [HttpGet("{id}")]
        public async Task<ActionResult<GrupoUsuario>> GetGrupoUsuario(int id)
        {
            var grupoUsuario = await _context.GrupoUsuarios.FindAsync(id);

            if (grupoUsuario == null)
            {
                return NotFound();
            }

            return grupoUsuario;
        }

        // PUT: api/GrupoUsuarios/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutGrupoUsuario(int id, GrupoUsuario grupoUsuario)
        {
            if (id != grupoUsuario.UsuarioId)
            {
                return BadRequest();
            }

            _context.Entry(grupoUsuario).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!GrupoUsuarioExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/GrupoUsuarios
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<GrupoUsuario>> PostGrupoUsuario(GrupoUsuario grupoUsuario)
        {
            _context.GrupoUsuarios.Add(grupoUsuario);
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                if (GrupoUsuarioExists(grupoUsuario.UsuarioId))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtAction("GetGrupoUsuario", new { id = grupoUsuario.UsuarioId }, grupoUsuario);
        }

        // DELETE: api/GrupoUsuarios/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteGrupoUsuario(int id)
        {
            var grupoUsuario = await _context.GrupoUsuarios.FindAsync(id);
            if (grupoUsuario == null)
            {
                return NotFound();
            }

            _context.GrupoUsuarios.Remove(grupoUsuario);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool GrupoUsuarioExists(int id)
        {
            return _context.GrupoUsuarios.Any(e => e.UsuarioId == id);
        }
    }
}
