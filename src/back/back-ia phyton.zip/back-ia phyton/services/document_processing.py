# services/document_processing.py

import io # Módulo para trabalhar com fluxos de E/S (input/output) em memória (como se fosse um arquivo)
import mimetypes # Módulo para adivinhar o tipo MIME de um arquivo (ex: 'application/pdf')
import logging # Módulo para registro de mensagens
from pypdf import PdfReader # Biblioteca para ler arquivos PDF
from docx import Document # Biblioteca para ler arquivos DOCX (documentos do Word)
import tiktoken # Biblioteca da OpenAI para codificar/decodificar texto em tokens
import os

# Configuração básica de logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# --- Função: extract_text_from_pdf() ---
# Responsável por extrair texto de arquivos PDF.

def extract_text_from_pdf(file_stream: io.BytesIO) -> str:
    """
    Extrai todo o texto de um arquivo PDF fornecido como um fluxo de bytes em memória.
    Retorna o texto extraído como uma string.
    """
    try:
        reader = PdfReader(file_stream)
        text = ""
        for page in reader.pages:
            text += page.extract_text() or ""
        logging.info("Texto extraído de PDF com sucesso.")
        return text
    except Exception as e:
        logging.error(f"Erro ao extrair texto de PDF: {e}")
        return ""

# --- Função: extract_text_from_docx() ---
# Responsável por extrair texto de arquivos DOCX.

def extract_text_from_docx(file_stream: io.BytesIO) -> str:
    """
    Extrai todo o texto de um arquivo DOCX (Word) fornecido como um fluxo de bytes em memória.
    Retorna o texto extraído como uma string.
    """
    try:
        document = Document(file_stream)
        full_text = []
        for para in document.paragraphs:
            full_text.append(para.text)
        logging.info("Texto extraído de DOCX com sucesso.")
        return '\n'.join(full_text)
    except Exception as e:
        logging.error(f"Erro ao extrair texto de DOCX: {e}")
        return ""

# --- Função: extract_text_from_file() ---
# Função principal para extrair texto de diferentes formatos de arquivo.

def extract_text_from_file(file_content: bytes, file_name: str) -> tuple[str, str]:
    """
    Extrai texto de vários tipos de arquivo (PDF, DOCX, TXT) com base na extensão do arquivo.
    Retorna uma tupla contendo o texto extraído (str) e o tipo MIME inferido (str).

    Argumentos:
    file_content (bytes): O conteúdo binário do arquivo.
    file_name (str): O nome original do arquivo (usado para adivinhar o tipo).
    """
    file_stream = io.BytesIO(file_content)
    file_type, _ = mimetypes.guess_type(file_name)
    
    if not file_type:
        logging.warning(f"Não foi possível determinar o tipo de arquivo para '{file_name}' pelo nome. Tentando genérico.")
        file_type = 'application/octet-stream'

    extracted_text = ""
    if file_type == 'application/pdf':
        extracted_text = extract_text_from_pdf(file_stream)
    elif file_type == 'application/vnd.openxmlformats-officedocument.wordprocessingml.document': # Tipo MIME para .docx
        extracted_text = extract_text_from_docx(file_stream)
    elif file_type == 'text/plain':
        extracted_text = file_stream.read().decode('utf-8', errors='ignore') 
        logging.info("Texto extraído de TXT com sucesso.")
    else:
        logging.warning(f"Tipo de arquivo '{file_type}' não suportado para extração de texto: {file_name}")
        extracted_text = ""
    
    logging.info(f"Texto extraído de '{file_name}' ({file_type}). Tamanho: {len(extracted_text)} caracteres.")
    return extracted_text, file_type

# --- Função: count_tokens() ---
# Contagem de tokens usando a biblioteca tiktoken da OpenAI.

def count_tokens(text: str, model_name: str = "cl100k_base") -> int:
    """
    Conta o número de tokens em um texto usando o tokenizer tiktoken.
    'cl100k_base' é o codificador para modelos GPT-3.5 e GPT-4.
    """
    try:
        encoding = tiktoken.get_encoding(model_name)
        return len(encoding.encode(text))
    except Exception as e:
        logging.warning(f"Não foi possível obter o encoding para o modelo '{model_name}'. Usando 'gpt-4' como fallback. Erro: {e}")
        encoding = tiktoken.encoding_for_model("gpt-4")
        return len(encoding.encode(text))

# --- Função: chunk_text() ---
# Divisão do texto em pedaços (chunks) para processamento por LLMs.

def chunk_text(text: str, max_tokens: int = 1000, overlap: int = 100) -> list[str]:
    """
    Divide um texto grande em chunks (pedaços menores) de tamanho máximo de tokens
    com uma sobreposição (overlap) entre os chunks para manter o contexto.

    Argumentos:
    text (str): O texto completo a ser dividido.
    max_tokens (int): O número máximo de tokens por chunk.
    overlap (int): O número de tokens que os chunks adjacentes se sobreporão.
    """
    if not text:
        return []

    encoding = tiktoken.get_encoding("cl100k_base") 
    tokens = encoding.encode(text) 
    
    chunks = []
    current_token_start_index = 0

    while current_token_start_index < len(tokens):
        current_token_end_index = min(current_token_start_index + max_tokens, len(tokens))
        chunk_tokens = tokens[current_token_start_index:current_token_end_index]
        chunks.append(encoding.decode(chunk_tokens))

        if current_token_end_index == len(tokens):
            break
        
        current_token_start_index += (max_tokens - overlap)
        if current_token_start_index < 0:
            current_token_start_index = 0
            
    logging.info(f"Texto dividido em {len(chunks)} chunks, com {max_tokens} tokens por chunk e {overlap} de overlap.")
    return chunks

# --- Bloco de Teste Individual ---
# services/document_processing.py

# ... (todo o código das funções acima)

# --- Bloco de Teste Individual ---
if __name__ == "__main__":
    logging.info("\n--- Iniciando teste do document_processing.py ---")

    # --- Teste com arquivo TXT --- (Este já funciona, não precisa mudar)
    logging.info("\n--- Testando extração e chunking de TXT ---")
    test_txt_content = b"Este e um documento de texto simples. Ele contem algumas informacoes importantes sobre o projeto CrowsIA. Vamos testar a extracao de texto e a divisao em chunks. O chunking e essencial para processar grandes volumes de texto com modelos de linguagem. Ele evita que a informacao exceda o limite de tokens do modelo e ajuda a focar na informacao relevante. A sobreposicao entre chunks garante que o contexto nao seja perdido nas bordas. Estamos adicionando mais texto para garantir que varios chunks sejam criados. Esta e a ultima frase do documento de teste."
    test_txt_name = "sample_document.txt"

    try:
        extracted_txt, txt_type = extract_text_from_file(test_txt_content, test_txt_name)
        logging.info(f"Extracao TXT SUCESSO. Tipo: {txt_type}, Tamanho: {len(extracted_txt)} chars.")
        
        tokens_txt = count_tokens(extracted_txt)
        logging.info(f"Tokens no TXT: {tokens_txt}")

        chunks_txt = chunk_text(extracted_txt, max_tokens=50, overlap=10)
        logging.info(f"Chunks TXT criados: {len(chunks_txt)}")
        for i, chunk in enumerate(chunks_txt):
            logging.info(f"  Chunk {i+1} ({count_tokens(chunk)} tokens): '{chunk[:50]}...'")

    except Exception as e:
        logging.error(f"Teste TXT FALHOU: {e}")

    # --- Teste com arquivo PDF REAL ---
    logging.info("\n--- Testando extração de PDF (REAL) ---")
    pdf_file_path = "../test_data/pdf/exemplo.pdf" # Caminho para seu arquivo PDF real
    try:
        with open(pdf_file_path, "rb") as f: # "rb" para ler em modo binário
            real_pdf_content = f.read()
        
        extracted_pdf, pdf_type = extract_text_from_file(real_pdf_content, os.path.basename(pdf_file_path)) # os.path.basename pega só o nome do arquivo
        logging.info(f"Extracao PDF SUCESSO. Tipo: {pdf_type}, Tamanho: {len(extracted_pdf)} chars.")
        if extracted_pdf:
            tokens_pdf = count_tokens(extracted_pdf)
            logging.info(f"Tokens no PDF: {tokens_pdf}")
            chunks_pdf = chunk_text(extracted_pdf, max_tokens=50, overlap=10)
            logging.info(f"Chunks PDF criados: {len(chunks_pdf)}")

    except FileNotFoundError:
        logging.warning(f"Teste PDF IGNORADO: Arquivo '{pdf_file_path}' nao encontrado. Crie um PDF real para testar.")
    except Exception as e:
        logging.error(f"Teste PDF FALHOU: {e}")

    # --- Teste com arquivo DOCX REAL ---
    logging.info("\n--- Testando extração de DOCX (REAL) ---")
    docx_file_path = "../test_data/docx/exemplo.docx" # Caminho para seu arquivo DOCX real
    try:
        with open(docx_file_path, "rb") as f: # "rb" para ler em modo binário
            real_docx_content = f.read()
        
        extracted_docx, docx_type = extract_text_from_file(real_docx_content, os.path.basename(docx_file_path))
        logging.info(f"Extracao DOCX SUCESSO. Tipo: {docx_type}, Tamanho: {len(extracted_docx)} chars.")
        if extracted_docx:
            tokens_docx = count_tokens(extracted_docx)
            logging.info(f"Tokens no DOCX: {tokens_docx}")
            chunks_docx = chunk_text(extracted_docx, max_tokens=50, overlap=10)
            logging.info(f"Chunks DOCX criados: {len(chunks_docx)}")

    except FileNotFoundError:
        logging.warning(f"Teste DOCX IGNORADO: Arquivo '{docx_file_path}' nao encontrado. Crie um DOCX real para testar.")
    except Exception as e:
        logging.error(f"Teste DOCX FALHOU: {e}")

    logging.info("\n--- Teste do document_processing.py CONCLUÍDO ---")