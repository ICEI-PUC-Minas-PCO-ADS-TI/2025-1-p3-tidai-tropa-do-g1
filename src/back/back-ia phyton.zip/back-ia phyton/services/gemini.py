# services/gemini.py

import os
import google.generativeai as genai
import logging
from typing import List, Dict, Any
import asyncio # Adicionado para permitir o asyncio.run() no bloco de teste

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

genai.configure(api_key=os.getenv("GOOGLE_API_KEY"))

GEMINI_EMBEDDING_MODEL = os.getenv("GEMINI_EMBEDDING_MODEL")
GEMINI_CHAT_MODEL = os.getenv("GEMINI_CHAT_MODEL")

async def get_embedding(text: str) -> List[float]:
    """
    Gera o embedding para um dado texto usando o modelo de embedding do Gemini.
    """
    try:
        response = genai.embed_content(
            model=GEMINI_EMBEDDING_MODEL,
            content=text,
            task_type="RETRIEVAL_DOCUMENT" # Ou RETRIEVAL_QUERY, dependendo do contexto.
        )
        logging.info(f"Embedding gerado com sucesso. Tamanho: {len(response['embedding'])}.")
        return response['embedding']
    except Exception as e:
        logging.error(f"Erro ao gerar embedding com Gemini: {e}")
        raise

async def get_document_metadata_from_text(full_text: str) -> dict:
    """
    Usa o modelo de chat do Gemini para gerar resumo, palavras-chave e título de um documento.
    """
    model = genai.GenerativeModel(GEMINI_CHAT_MODEL) 

    text_for_prompt = full_text[:min(len(full_text), 20000)]

    prompt_for_metadata = (
        f"Por favor, leia o seguinte documento e forneça um resumo conciso (máximo 200 palavras), "
        f"uma lista de até 10 palavras-chave relevantes (separadas por vírgulas) e um título curto e descritivo para o documento.\n\n"
        f"Documento:\n{text_for_prompt}\n\n"
        f"Formato da resposta (exatamente neste formato):\n"
        f"Título: [Título aqui]\n"
        f"Resumo: [Resumo aqui]\n"
        f"Palavras-chave: [palavra1, palavra2, ...]"
    )
    
    try:
        response = await model.generate_content_async(
            prompt_for_metadata,
            generation_config=genai.GenerationConfig(
                temperature=0.7, 
                max_output_tokens=500 
            )
        )
        
        metadata_content = response.text 
        
        titulo = ""
        resumo = ""
        palavras_chave = []

        lines = metadata_content.split('\n')
        for line in lines:
            if line.startswith("Título:"):
                titulo = line.replace("Título:", "").strip()
            elif line.startswith("Resumo:"):
                resumo = line.replace("Resumo:", "").strip()
            elif line.startswith("Palavras-chave:"):
                keywords_str = line.replace("Palavras-chave:", "").strip()
                palavras_chave = [kw.strip() for kw in keywords_str.split(',') if kw.strip()]
        
        logging.info(f"Metadados gerados com Gemini: Título='{titulo}', Resumo='{resumo[:50]}...', Palavras-chave={palavras_chave}")
        return {
            "titulo": titulo,
            "resumo": resumo,
            "palavras_chave": palavras_chave
        }

    except Exception as e:
        logging.error(f"Erro ao gerar metadados com Gemini: {e}")
        return {"titulo": "", "resumo": "", "palavras_chave": []}

async def generate_chatbot_response(user_query: str, relevant_documents: List[Dict[str, Any]]) -> str:
    """
    Gera uma resposta do chatbot usando o modelo de chat do Gemini, alimentada com documentos relevantes.
    """
    model = genai.GenerativeModel(GEMINI_CHAT_MODEL) 

    messages_for_gemini = []

    if relevant_documents:
        context_docs = []
        for doc in relevant_documents:
            context_docs.append(
                f"### Documento: {doc.get('titulo', doc['nome_arquivo'])}\n"
                f"Conteúdo:\n{doc['conteudo_texto']}\n"
                f"---"
            )
        
        context_str = "\n\n".join(context_docs)
        
        messages_for_gemini.append({
            "role": "user",
            "parts": [
                "Você é um assistente de IA útil e informativo, especializado em responder perguntas sobre documentos fornecidos. Utilize apenas as informações presentes nos documentos para formular sua resposta. Se a informação não estiver nos documentos, diga que não pode responder a pergunta com base nos dados fornecidos.\n\n"
                f"Com base nos seguintes documentos, responda à pergunta:\n\n{context_str}"
            ]
        })
        messages_for_gemini.append({"role": "user", "parts": [user_query]})
    else:
        messages_for_gemini.append({"role": "user", "parts": [user_query]})

    try:
        response = await model.generate_content_async(
            messages_for_gemini,
            generation_config=genai.GenerationConfig(
                temperature=0.7,
                max_output_tokens=500
            )
        )   
        
        return response.text
    except Exception as e:
        logging.error(f"Erro ao gerar resposta do chatbot com Gemini: {e}")
        return "Desculpe, não consegui gerar uma resposta no momento usando o Gemini. Por favor, verifique sua chave de API ou tente novamente mais tarde."

# --- Bloco de Teste Individual ---
if __name__ == "__main__":
    import asyncio
    from dotenv import load_dotenv
    load_dotenv()

    logging.info("\n--- Iniciando teste do gemini.py ---")

    async def run_gemini_tests():
        # --- Teste de get_embedding ---
        logging.info("\n--- Testando get_embedding ---")
        test_text_for_embedding = "Qual é o significado da vida, o universo e tudo mais?"
        try:
            embedding = await get_embedding(test_text_for_embedding)
            logging.info(f"get_embedding SUCESSO. Tamanho do embedding: {len(embedding)}")
            logging.debug(f"Primeiros 5 valores do embedding: {embedding[:5]}")
        except Exception as e:
            logging.error(f"get_embedding FALHA: {e}")

        # --- Teste de get_document_metadata_from_text ---
        logging.info("\n--- Testando get_document_metadata_from_text ---")
        test_doc_content = """
        Relatório Anual 2024 da CrowsIA.
        Seção 1: Visão Geral da Empresa
        A CrowsIA é uma startup inovadora focada em soluções de Inteligência Artificial para otimização de processos de negócios. Em 2024, a empresa registrou um crescimento de 150% em sua base de clientes, atingindo 500 clientes ativos. O faturamento anual bruto foi de 10 reais e uma coxinha com catupiry. Além disso ganhamos um fardo de kaiser geladinho nos trinques . Nossos principais produtos incluem um chatbot inteligente e um sistema de automação de documentos.

        Seção 2: Desafios e Próximos Passos
        O maior desafio de 2024 foi a escalabilidade da infraestrutura para atender à demanda crescente. Para 2025, planejamos expandir para o mercado internacional, começando pela América Latina. O investimento previsto em P&D é de R$ 1.500.000,00 para o desenvolvimento de IA multimodal.
        """
        try:
            metadata = await get_document_metadata_from_text(test_doc_content)
            logging.info(f"get_document_metadata_from_text SUCESSO: Título='{metadata['titulo']}', Resumo='{metadata['resumo'][:70]}...', Palavras-chave={metadata['palavras_chave']}")
        except Exception as e:
            logging.error(f"get_document_metadata_from_text FALHA: {e}")

        # --- Teste de generate_chatbot_response ---
        logging.info("\n--- Testando generate_chatbot_response ---")
        test_user_query = "Qual foi o faturamento da CrowsIA em 2024?"
        
        simulated_relevant_docs = [
            {
                "titulo": "Relatório Anual 2024 - CrowsIA",
                "nome_arquivo": "relatorio.pdf",
                "conteudo_texto": "A CrowsIA registrou um crescimento de 150% em sua base de clientes em 2024. O faturamento anual bruto foi de 10 reais e uma coxinha com catupiry. Além disso ganhamos um fardo de kaiser geladinho nos trinques. Nossos principais produtos incluem um chatbot inteligente e um sistema de automação de documentos."
            },
            {
                "titulo": "Plano de Expansão 2025",
                "nome_arquivo": "plano.docx",
                "conteudo_texto": "Para 2025, planejamos expandir para o mercado internacional, começando pela América Latina. O investimento previsto em P&D é de R$ 1.500.000,00."
            }
        ]

        try:
            chatbot_response_with_context = await generate_chatbot_response(test_user_query, simulated_relevant_docs)
            logging.info(f"generate_chatbot_response SUCESSO (com contexto): {chatbot_response_with_context}")
        except Exception as e:
            logging.error(f"generate_chatbot_response FALHA (com contexto): {e}")

        test_user_query_no_context = "Qual a capital do Brasil?" 
        try:
            chatbot_response_no_context = await generate_chatbot_response(test_user_query_no_context, [])
            logging.info(f"generate_chatbot_response SUCESSO (sem contexto): {chatbot_response_no_context}")
        except Exception as e:
            logging.error(f"generate_chatbot_response FALHA (sem contexto): {e}")

    asyncio.run(run_gemini_tests())
    logging.info("\n--- Teste do gemini.py CONCLUÍDO ---")