# services/db.py

import os
import uuid
import psycopg2
from psycopg2 import sql
from psycopg2.extras import execute_values
import logging
from pgvector.psycopg2 import register_vector # <-- LINHA ADICIONADA: Importa a função para registrar o tipo VECTOR

# Configuração básica de logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

def get_db_connection():
    """
    Estabelece e retorna uma conexão com o banco de dados PostgreSQL.
    Registra o adaptador pgvector para o tipo VECTOR.
    """
    conn = None # Inicializa a variável de conexão
    try:
        conn = psycopg2.connect(
            dbname=os.getenv("POSTGRES_DB"),
            user=os.getenv("POSTGRES_USER"),
            password=os.getenv("POSTGRES_PASSWORD"),
            host=os.getenv("POSTGRES_HOST"),
            port=os.getenv("POSTGRES_PORT")
        )
        register_vector(conn) # <-- LINHA ADICIONADA: Registra o adaptador para o tipo VECTOR para esta conexão
        print("DEBUG: register_vector(conn) executado com sucesso.") # <-- ADICIONE ESTA LINHA
        return conn
    except Exception as e:
        logging.error(f"Erro ao conectar ao banco de dados: {e}")
        raise

def save_document(doc_data: dict) -> int:
    """
    Salva as informações básicas de um documento na tabela 'documentos'.
    Recebe um dicionário (dict) com os dados do documento.
    Retorna o ID (SERIAL) do documento inserido.
    """
    conn = None
    try:
        conn = get_db_connection()
        cur = conn.cursor()

        insert_document_query = sql.SQL("""
            INSERT INTO documentos (nome_arquivo, titulo, url_blob, tipo, resumo, palavras_chave, usuario_id)
            VALUES (%s, %s, %s, %s, %s, %s, %s) RETURNING id;
        """)
        cur.execute(insert_document_query, (
            doc_data["nome_arquivo"],
            doc_data.get("titulo"),
            doc_data["url_blob"],
            doc_data["tipo"],
            doc_data.get("resumo"),
            doc_data.get("palavras_chave"),
            doc_data["usuario_id"]
        ))
        
        inserted_document_id = cur.fetchone()[0]
        conn.commit()
        logging.info(f"Documento '{doc_data['nome_arquivo']}' salvo com ID: {inserted_document_id}")
        return inserted_document_id
    except Exception as e:
        logging.error(f"Erro ao salvar documento no banco de dados: {e}")
        if conn:
            conn.rollback()
        raise
    finally:
        if conn:
            cur.close()
            conn.close()

def save_document_chunks(document_id: int, chunks_data: list[dict]):
    """
    Salva os chunks de conteúdo e seus embeddings na tabela 'conteudos_documento'.
    document_id: O ID do documento pai (da tabela documentos).
    chunks_data: Uma lista de dicionários, cada um contendo 'conteudo_texto', 'embedding' e 'ordem'.
    """
    if not chunks_data:
        logging.warning(f"Nenhum chunk para salvar para o documento ID {document_id}.")
        return

    conn = None
    try:
        conn = get_db_connection()
        cur = conn.cursor()

        insert_chunks_query = sql.SQL("""
            INSERT INTO conteudos_documento (documento_id, conteudo_texto, embedding, ordem)
            VALUES %s;
        """)
        values_to_insert = [
            (document_id, chunk["conteudo_texto"], chunk["embedding"], chunk["ordem"])
            for chunk in chunks_data
        ]
        
        execute_values(cur, insert_chunks_query, values_to_insert, page_size=100)
        
        conn.commit()
        logging.info(f"{len(values_to_insert)} chunks inseridos para o documento {document_id}.") # Corrigido para values_to_insert
    except Exception as e:
        logging.error(f"Erro ao salvar chunks no banco de dados para documento {document_id}: {e}")
        if conn:
            conn.rollback()
        raise
    finally:
        if conn:
            cur.close()
            conn.close()

def search_document_chunks_by_embedding(query_embedding: list[float], user_id: int, top_k: int = 3) -> list[dict]:
    """
    Busca os chunks de documentos mais relevantes por similaridade de cosseno.
    Filtra por user_id (para que um usuário veja apenas seus próprios documentos).
    """
    conn = None
    try:
        conn = get_db_connection()
        cur = conn.cursor()

        # LINHA ALTERADA AQUI: Adicionado '::vector' para forçar o cast do tipo
        query_sql = sql.SQL("""
            SELECT 
                cd.conteudo_texto, 
                d.id AS documento_id, 
                d.nome_arquivo, 
                d.titulo, 
                d.resumo, 
                d.palavras_chave, 
                (cd.embedding <=> %s::vector) AS cosine_distance -- <-- MUDANÇA NESTA LINHA
            FROM conteudos_documento cd
            JOIN documentos d ON cd.documento_id = d.id
            WHERE d.usuario_id = %s
            ORDER BY cosine_distance ASC
            LIMIT %s;
        """)
        
        cur.execute(query_sql, (query_embedding, user_id, top_k))
        
        results = []
        columns = [desc[0] for desc in cur.description]
        
        for row in cur.fetchall():
            results.append(dict(zip(columns, row))) 
        
        logging.info(f"Busca por similaridade retornou {len(results)} chunks para a query do usuário {user_id}.")
        return results

    except Exception as e:
        logging.error(f"Erro ao buscar documentos por similaridade: {e}")
        raise
    finally:
        if conn:
            cur.close()
            conn.close()

            
# --- Bloco de Teste Individual ---
if __name__ == "__main__":
    from dotenv import load_dotenv
    load_dotenv()

    logging.info("\n--- Iniciando teste do db.py ---")

    # --- Teste de save_document ---
    logging.info("\n--- Testando save_document ---")
    test_user_id = 1 # Use um ID de usuário de teste (pode ser o ID de um usuário do seu backend C# se quiser)
    
    test_doc_data = {
        "nome_arquivo": "documento_teste_db_v2.pdf", # Nome diferente para evitar conflito de teste
        "titulo": "Título de Teste do Documento DB V2",
        "url_blob": "http://example.com/test_doc_db_v2.pdf",
        "tipo": "application/pdf",
        "resumo": "Este é um resumo de teste para um documento de exemplo para o db.py. Versão 2.",
        "palavras_chave": ["teste", "documento", "db", "exemplo", "v2"],
        "usuario_id": test_user_id
    }
    
    inserted_doc_id = None
    try:
        inserted_doc_id = save_document(test_doc_data)
        logging.info(f"save_document SUCESSO: Documento inserido com ID: {inserted_doc_id}")
    except Exception as e:
        logging.error(f"save_document FALHA: {e}")

    # --- Teste de save_document_chunks ---
    if inserted_doc_id:
        logging.info("\n--- Testando save_document_chunks ---")
        # Criando embeddings de exemplo (apenas números aleatórios para simular embeddings reais)
        # O tamanho deve ser 1536, conforme definido na sua tabela.
        test_embedding_1 = [0.1] * 1536 
        test_embedding_2 = [0.2] * 1536 
        
        test_chunks_data = [
            {
                "conteudo_texto": "Este é o primeiro chunk de texto de teste para o documento V2.",
                "embedding": test_embedding_1,
                "ordem": 0
            },
            {
                "conteudo_texto": "Este é o segundo chunk de texto, continuando a informação do primeiro V2.",
                "embedding": test_embedding_2,
                "ordem": 1
            }
        ]

        try:
            save_document_chunks(inserted_doc_id, test_chunks_data)
            logging.info("save_document_chunks SUCESSO: Chunks inseridos.")
        except Exception as e:
            logging.error(f"save_document_chunks FALHA: {e}")
    else:
        logging.warning("save_document_chunks IGNORADO: Nenhum documento inserido para associar os chunks.")

    # --- Teste de search_document_chunks_by_embedding ---
    logging.info("\n--- Testando search_document_chunks_by_embedding ---")
    
    test_query_embedding = [0.15] * 1536 # Um embedding "próximo" aos de teste (0.1 e 0.2)

    try:
        found_chunks = search_document_chunks_by_embedding(test_query_embedding, test_user_id, top_k=1)
        if found_chunks:
            logging.info(f"search_document_chunks_by_embedding SUCESSO: Encontrados {len(found_chunks)} chunks.")
            for chunk in found_chunks:
                # Imprime apenas uma parte do texto e o nome do arquivo para melhor visualização
                logging.info(f"  - Chunk (ID Documento: {chunk['documento_id']}, Nome Arquivo: {chunk['nome_arquivo']}, Distância: {chunk['cosine_distance']:.4f}): '{chunk['conteudo_texto'][:50]}...'")
        else:
            logging.info("search_document_chunks_by_embedding: Nenhum chunk encontrado.")
    except Exception as e:
        logging.error(f"search_document_chunks_by_embedding FALHA: {e}")

    logging.info("\n--- Teste do db.py CONCLUÍDO ---")