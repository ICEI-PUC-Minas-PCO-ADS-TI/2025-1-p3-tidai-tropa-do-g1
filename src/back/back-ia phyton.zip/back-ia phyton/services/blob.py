# services/blob.py

import os
import uuid
from azure.storage.blob import BlobServiceClient
import logging

# Configuração básica de logging:
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# Obtém as credenciais e configurações do Blob Storage do arquivo .env
# Estas variáveis agora serão carregadas corretamente porque load_dotenv() já foi chamado.
BLOB_CONNECTION_STRING = os.getenv("AZURE_BLOB_CONNECTION_STRING")
BLOB_CONTAINER_NAME = os.getenv("AZURE_BLOB_CONTAINER_NAME")

# --- Função: upload_file_to_blob() ---

def upload_file_to_blob(file_name: str, file_content: bytes, user_id: int) -> str:
    """
    Faz o upload de um arquivo (seu conteúdo em bytes) para o Azure Blob Storage.
    Retorna a URL pública (string) do blob que foi criado.

    Argumentos:
    file_name (str): O nome original do arquivo que está sendo enviado (ex: "contrato.pdf").
    file_content (bytes): O conteúdo binário do arquivo.
    user_id (int): O ID do usuário que fez o upload. Usado para organizar os blobs dentro do contêiner.
    """
    try:
        blob_service_client = BlobServiceClient.from_connection_string(BLOB_CONNECTION_STRING)
        container_client = blob_service_client.get_container_client(BLOB_CONTAINER_NAME)
        
        if not container_client.exists():
            logging.info(f"Container '{BLOB_CONTAINER_NAME}' não encontrado. Criando...")
            container_client.create_container()

        blob_name = f"{user_id}/{uuid.uuid4()}_{file_name}"
        blob_client = container_client.get_blob_client(blob_name)
        
        blob_client.upload_blob(file_content, overwrite=True)
        
        logging.info(f"Documento '{file_name}' enviado para o Blob Storage em: {blob_client.url}")
        
        return blob_client.url
    except Exception as e:
        logging.error(f"Erro ao fazer upload para o Blob Storage: {e}")
        raise

# --- Bloco de Teste Individual ---
# Este bloco de código só será executado quando você rodar 'python services/blob.py' diretamente.
if __name__ == "__main__":
    # NÃO PRECISA MAIS DE load_dotenv() AQUI, POIS JÁ FOI CHAMADO NO TOPO DO ARQUIVO.
    # from dotenv import load_dotenv
    # load_dotenv() 

    logging.info("\n--- Iniciando teste do blob.py ---")

    test_file_name = "documento_teste_blob_from_python.txt"
    test_file_content = b"Este e um conteudo de teste para o Azure Blob Storage, enviado do script Python."
    test_user_id = 123 

    try:
        logging.info(f"Tentando fazer upload do arquivo: {test_file_name}")
        uploaded_url = upload_file_to_blob(test_file_name, test_file_content, test_user_id)
        logging.info(f"upload_file_to_blob SUCESSO: Arquivo enviado para: {uploaded_url}")

        logging.info("\n--- Verificação Manual ---")
        logging.info("Por favor, verifique sua conta de Armazenamento no portal do Azure.")
        logging.info(f"Container: {os.getenv('AZURE_BLOB_CONTAINER_NAME')}")
        logging.info(f"Você deverá encontrar o arquivo '{test_file_name}' dentro da 'pasta virtual' '{test_user_id}/'.")

    except Exception as e:
        logging.error(f"upload_file_to_blob FALHA: {e}")

    logging.info("\n--- Teste do blob.py CONCLUÍDO ---")