# app.py

import asyncio
import os
import logging
from typing import Optional, List
from dotenv import load_dotenv

# Importações do FastAPI
from fastapi import FastAPI, UploadFile, File, Form, HTTPException, status
from fastapi.responses import JSONResponse # Para retornar respostas JSON personalizadas
from pydantic import BaseModel # Para criar modelos de dados para requisições JSON

# Carrega as variáveis de ambiente do arquivo .env IMEDIATAMENTE AQUI.
load_dotenv()

# Configuração básica de logging para a aplicação
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# Importa as funções dos seus módulos de serviço.
from services.db import save_document, save_document_chunks, search_document_chunks_by_embedding
from services.blob import upload_file_to_blob
from services.gemini import get_embedding, get_document_metadata_from_text, generate_chatbot_response
from services.document_processing import extract_text_from_file, chunk_text, count_tokens

# --- Instância da Aplicação FastAPI ---
app = FastAPI(
    title="CrowsIA Document AI Backend",
    description="API para upload de documentos, extração de IA (resumo, embeddings) e chatbot RAG.",
    version="1.0.0"
)

# ====================================================================================
# --- ADICIONE ESTE BLOCO DE CONFIGURAÇÃO DE CORS AQUI ABAIXO DE 'app = FastAPI(...)' ---
# ====================================================================================

# Importa o CORSMiddleware. Certifique-se que esta linha está no topo com as outras importacoes
from fastapi.middleware.cors import CORSMiddleware

# Lista de origens permitidas para requisições CORS
# Adicione aqui TODAS as URLs de onde seu frontend pode acessar esta API.
# Durante o desenvolvimento, 'http://localhost:PORTA' é comum.
# Em produção, será o domínio do seu frontend (ex: "https://seufrotend.com").
origins = [
    "http://localhost",        # Para o caso de abrir o HTML/JS direto do disco
    "http://localhost:3000",   # Muito comum para apps React em desenvolvimento (porta padrão)
    "http://localhost:8080",   # Outra porta comum para React/Dev
    "http://127.0.0.1:3000",   # Às vezes o navegador usa 127.0.0.1 em vez de localhost
    "http://127.0.0.1:8080",   # Outra para 127.0.0.1
    # Adicione aqui os domínios do seu frontend em producao (ex: "https://seufrotend.com")
]

# Adiciona o middleware CORS à aplicação FastAPI
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,       # Define as origens permitidas
    allow_credentials=True,      # Permite o envio de cookies e credenciais HTTP com a requisição CORS
    allow_methods=["*"],         # Permite todos os métodos HTTP (GET, POST, PUT, DELETE, OPTIONS, etc.)
    allow_headers=["*"],         # Permite todos os cabeçalhos HTTP na requisição CORS
)

# ====================================================================================
# --- AS ROTAS DA API (@app.post, @app.get) DEVEM COMEÇAR APÓS O BLOCO CORS ---
# ====================================================================================


# --- Modelos Pydantic para Validação de Requisições ---
# Isso é como definir o schema de um JSON que você espera no Node.js
class ChatQuery(BaseModel):
    query: str
    user_id: int

# --- Funções de Orquestração do Fluxo Principal (mantidas do seu código anterior) ---

async def process_document_upload_flow(file_name: str, file_content: bytes, user_id: int):
    logging.info(f"Iniciando processamento do documento: {file_name} para o usuário ID: {user_id}")
    try:
        logging.info("Passo 1: Fazendo upload para Blob Storage...")
        blob_url = upload_file_to_blob(file_name, file_content, user_id)
        logging.info(f"Upload para Blob Storage concluído. URL: {blob_url}")

        logging.info("Passo 2: Extraindo texto do documento...")
        full_text, file_type = extract_text_from_file(file_content, file_name)
        if not full_text:
            logging.warning(f"Não foi possível extrair texto do documento '{file_name}'.")
            # Em um cenário real, você pode querer lançar um erro se o documento for inviável
        logging.info(f"Extração de texto concluída. Tamanho: {len(full_text)} caracteres.")

        logging.info("Passo 3: Gerando metadados (resumo, palavras-chave, título) com IA (Gemini)...")
        metadata = await get_document_metadata_from_text(full_text)
        logging.info(f"Geração de metadados concluída. Título: '{metadata.get('titulo', 'N/A')}'")
        
        logging.info("Passo 4: Salvando metadados do documento no banco de dados...")
        document_id = save_document({
            "nome_arquivo": file_name,
            "titulo": metadata.get("titulo", file_name.rsplit('.', 1)[0]),
            "url_blob": blob_url,
            "tipo": file_type,
            "resumo": metadata.get("resumo"),
            "palavras_chave": metadata.get("palavras_chave"),
            "usuario_id": user_id
        })
        logging.info(f"Documento salvo no DB com ID: {document_id}")

        logging.info("Passo 5: Dividindo texto em chunks e gerando embeddings (Gemini)...")
        text_chunks = chunk_text(full_text, max_tokens=800, overlap=100) 
        
        embeddings_to_save = []
        for i, chunk in enumerate(text_chunks):
            if chunk.strip():
                chunk_embedding = await get_embedding(chunk) 
                embeddings_to_save.append({
                    "conteudo_texto": chunk,
                    "embedding": chunk_embedding,
                    "ordem": i
                })
            else:
                logging.warning(f"Chunk vazio encontrado para o documento '{file_name}'. Ignorando.")
        logging.info(f"Embeddings gerados para {len(embeddings_to_save)} chunks.")

        logging.info("Passo 6: Salvando chunks e embeddings no banco de dados...")
        save_document_chunks(document_id, embeddings_to_save)
        logging.info(f"Chunks e embeddings salvos para o documento {document_id}.")

        logging.info(f"Processamento completo do documento '{file_name}' CONCLUÍDO COM SUCESSO! Documento ID: {document_id}")
        return {"status": "success", "document_id": document_id, "message": "Documento processado e salvo."}

    except Exception as e:
        logging.error(f"Falha no processamento do documento '{file_name}': {e}")
        # Lança uma exceção HTTP para o FastAPI capturar e retornar um erro 500
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Erro interno no processamento do documento: {str(e)}"
        )

async def handle_chatbot_query_flow(user_query: str, user_id: int):
    logging.info(f"Recebida consulta do chatbot: '{user_query}' para o usuário ID: {user_id}")
    try:
        logging.info("Passo 1: Gerando embedding da pergunta (Gemini)...")
        query_embedding = await get_embedding(user_query) 
        logging.info("Embedding da pergunta gerado.")

        logging.info("Passo 2: Buscando chunks relevantes no banco de dados...")
        relevant_chunks = search_document_chunks_by_embedding(query_embedding, user_id, top_k=3) 
        if not relevant_chunks:
            logging.info("Nenhum chunk relevante encontrado para a consulta.")
        else:
            logging.info(f"Encontrados {len(relevant_chunks)} chunks relevantes.")

        logging.info("Passo 3: Gerando resposta do chatbot com IA (Gemini) e contexto dos documentos...")
        chatbot_response = await generate_chatbot_response(user_query, relevant_chunks)
        logging.info(f"Resposta do chatbot gerada.")

        logging.info(f"Consulta do chatbot para '{user_query}' CONCLUÍDA COM SUCESSO.")
        return {"status": "success", "response": chatbot_response, "relevant_docs_count": len(relevant_chunks)}

    except Exception as e:
        logging.error(f"Falha na consulta do chatbot para '{user_query}': {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Erro interno na consulta do chatbot: {str(e)}"
        )

# --- Definição dos Endpoints REST da API ---

@app.post("/documents/upload/")
async def upload_document(
    file: UploadFile = File(...), # 'File(...)' indica que é um arquivo obrigatório
    user_id: int = Form(...),     # 'Form(...)' para user_id vindo de um campo de formulário
    # user_id: int = Header(..., alias="X-User-ID") # Alternativa: user_id vindo de um header HTTP
):
    """
    Endpoint para fazer upload de um documento, processá-lo com IA e indexá-lo.
    Retorna o status do processamento e o ID do documento.
    """
    logging.info(f"Requisição de upload recebida para arquivo: {file.filename} e user_id: {user_id}")
    
    # Validação básica do tipo de arquivo (FastAPI faz parte da validação automática)
    if not file.filename:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Nome do arquivo não fornecido.")
    
    # Lê o conteúdo do arquivo como bytes
    file_content = await file.read()

    # Chama o fluxo de orquestração principal
    return await process_document_upload_flow(file.filename, file_content, user_id)


@app.post("/chatbot/query/")
async def chatbot_query(chat_data: ChatQuery):
    """
    Endpoint para enviar uma pergunta ao chatbot.
    Recebe a pergunta do usuário e o ID do usuário.
    Retorna a resposta do chatbot.
    """
    logging.info(f"Requisição de chatbot recebida. Pergunta: '{chat_data.query}' para user_id: {chat_data.user_id}")
    
    # Chama o fluxo de orquestração principal
    return await handle_chatbot_query_flow(chat_data.query, chat_data.user_id)


# --- Rota Raiz (Opcional, para verificar se a API está rodando) ---
@app.get("/")
async def read_root():
    return {"message": "Bem-vindo ao CrowsIA Document AI Backend! A API está funcionando."}

from services.db import get_db_connection # Importe get_db_connection aqui para usar diretamente
from psycopg2 import sql # Importe sql para queries seguras

@app.get("/documents/list/{user_id}")
async def list_documents_for_user(user_id: int):
    """
    Endpoint para listar todos os documentos de um usuário específico.
    Filtra os documentos pelo usuario_id e retorna detalhes relevantes.
    """
    logging.info(f"Requisição de listagem de documentos para user_id: {user_id}")
    conn = None
    try:
        conn = get_db_connection() # Obtém uma conexão com o DB
        cur = conn.cursor()        # Cria um cursor

        # Query SQL para selecionar documentos da tabela 'documentos'
        # Filtra por usuario_id e ordena pela data de upload mais recente
        query_sql = sql.SQL("""
            SELECT id, nome_arquivo, titulo, url_blob, data_upload, tipo, resumo, palavras_chave
            FROM documentos
            WHERE usuario_id = %s
            ORDER BY data_upload DESC;
        """)
        
        cur.execute(query_sql, (user_id,)) # Executa a query com o user_id

        results = []
        # Obtém os nomes das colunas para criar dicionários mais legíveis
        columns = [desc[0] for desc in cur.description]
        for row in cur.fetchall():
            results.append(dict(zip(columns, row))) # Converte a tupla da linha em dicionário
        
        logging.info(f"Listagem de documentos retornou {len(results)} para o usuário {user_id}.")
        return results # Retorna a lista de documentos como JSON

    except Exception as e:
        logging.error(f"Erro ao listar documentos para user_id {user_id}: {e}")
        # Lança uma exceção HTTP para o FastAPI capturar e retornar um erro 500
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Erro interno ao listar documentos: {str(e)}"
        )
    finally:
        # Garante que o cursor e a conexão sejam fechados
        if conn:
            cur.close()
            conn.close()


# Para rodar a aplicação localmente, use: uvicorn app:app --reload --host 0.0.0.0 --port 8000
# 'app:app' significa arquivo 'app.py', objeto 'app' dentro dele.
# --reload para reiniciar o servidor automaticamente ao salvar mudanças.
# --host 0.0.0.0 para aceitar conexoes de qualquer IP (útil em docker/VMs).
# --port 8000 para rodar na porta 8000.